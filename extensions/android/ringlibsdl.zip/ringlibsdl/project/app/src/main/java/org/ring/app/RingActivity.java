package org.ring.app;

import org.libsdl.app.SDLActivity;

public class RingActivity extends SDLActivity
{
	// You can add your own stuff here if you need to
}